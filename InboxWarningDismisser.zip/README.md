# chrome-inbox-warning-dismisser
A simple chrome extension that dismisses Google's Inbox end of life warning


# How to Load
* Go to the extensions and turn on the developer mode
* Click on `Load unpacked`and load the folder of the extension.
